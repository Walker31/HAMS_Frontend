import React from 'react';
import { FaBell } from 'react-icons/fa';

const Header = () => (
  <header className="flex justify-between items-center mb-6">
    <div>
      <h1 className="text-2xl font-bold">Health Dashboard</h1>
      <p className="text-sm text-gray-600">Welcome back, Atheeb!</p>
    </div>
    <div className="flex items-center space-x-4">
      <FaBell className="text-gray-500 text-xl" />
      <img className="w-8 h-8 rounded-full" src="https://i.pravatar.cc/40" alt="profile" />
    </div>
  </header>
);

export default Header;